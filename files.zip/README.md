# eFootball HQ – MBAVU TATU

A full tournament management web app for eFootball mobile, deployable on GitHub Pages with Firebase Realtime Database.

---

## 🚀 Deployment: Step-by-Step

### Step 1 — Create a GitHub repository

1. Go to [github.com](https://github.com) and log in (or create a free account)
2. Click **New repository**
3. Name it: `efootball-hq`
4. Set to **Public**
5. Click **Create repository**

---

### Step 2 — Upload the app

Option A (easiest — drag & drop):
1. Open your new repo on GitHub
2. Click **Add file → Upload files**
3. Drag `index.html` into the upload area
4. Click **Commit changes**

Option B (Git CLI):
```bash
git init
git add index.html
git commit -m "Initial deploy"
git remote add origin https://github.com/YOUR_USERNAME/efootball-hq.git
git push -u origin main
```

---

### Step 3 — Enable GitHub Pages

1. In your repo, click **Settings**
2. Scroll to **Pages** (left sidebar)
3. Under **Source**, select: `Deploy from branch`
4. Branch: `main` → folder: `/ (root)`
5. Click **Save**

Your app will be live at:
`https://YOUR_USERNAME.github.io/efootball-hq/`

(Takes ~2 minutes to go live)

---

### Step 4 — Set up Firebase (free database)

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → name it `efootball-hq` → Continue
3. Disable Google Analytics (not needed) → **Create project**

#### Enable Firestore:
1. In the sidebar click **Firestore Database**
2. Click **Create database**
3. Choose **Start in test mode** (allows read/write for 30 days — you'll secure it later)
4. Pick a region (e.g. `europe-west1` for East Africa)
5. Click **Enable**

#### Get your config:
1. Click the gear icon ⚙️ → **Project settings**
2. Scroll to **Your apps** → click the `</>` (web) icon
3. Register app name: `efootball-hq` → click **Register app**
4. Copy the `firebaseConfig` object — it looks like:

```js
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "efootball-hq.firebaseapp.com",
  projectId: "efootball-hq",
  storageBucket: "efootball-hq.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123:web:abc123"
};
```

---

### Step 5 — Add your Firebase config to the app

1. Open `index.html` in any text editor (Notepad, VS Code, etc.)
2. Find this section near the top (line ~20):

```js
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  ...
```

3. Replace it with your actual config values from Step 4
4. Save the file
5. Re-upload to GitHub (or push via Git)

---

### Step 6 — Change the admin password

In the admin panel → **Tournament** tab → change the **Admin password** field and click **Save settings**.

Default credentials (change immediately!):
- Username: `admin`
- Password: `mbavutatu`

---

## ✅ Features summary

| Feature | Details |
|---|---|
| Bracket generation | Powers of 2 only (2–128). Rejects invalid counts. |
| 2-leg rule | From Round of 16 down to Semi-final. Final is 1-legged. |
| Player randomization | Bracket is shuffled on every generation |
| Firebase sync | Real-time — all devices see updates instantly |
| Registration | Players register via form; admin verifies payment |
| Registration link | Shareable link with custom tournament code |
| Admin panel | Password-protected; verify players, manage settings |
| Fixture cards | Canvas-rendered JPEG cards, downloadable per match |
| Player profiles | Name, team, playing style, avatar colour, bio |
| AI assistant | Claude-powered assistant for announcements, rules, etc. |

---

## 🔒 Securing Firebase (after testing)

In Firebase Console → Firestore → **Rules**, replace test rules with:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /players/{id} {
      allow read: if true;
      allow write: if false; // lock writes to admin only via Firebase Auth
    }
    match /meta/{id} {
      allow read: if true;
      allow write: if false;
    }
  }
}
```

For full admin-only writes, enable Firebase Authentication and update rules accordingly.

---

## 📱 Sharing with players

After deployment, share:
- **App link**: `https://YOUR_USERNAME.github.io/efootball-hq/`
- **Registration link**: Generated in the Register tab → copy and send via WhatsApp

---

## 🛠 Tech stack

- HTML / CSS / Vanilla JS (no frameworks, no build step)
- Firebase Firestore (free tier: 1GB storage, 50k reads/day, 20k writes/day)
- GitHub Pages (free hosting)
- Anthropic Claude API (AI assistant in admin panel)
- HTML Canvas (fixture card generation)
